package br.com.porteirofacil

import android.app.Application
import br.com.porteirofacil.data.local.AppDatabase
import br.com.porteirofacil.data.repository.StudentRepository
import br.com.porteirofacil.security.SecureConfig

class PorteiroApplication : Application() {
    val database by lazy { AppDatabase.get(this) }
    val secureConfig by lazy { SecureConfig(this) }
    val repository by lazy { StudentRepository(this, database, secureConfig) }
}
