package br.com.porteirofacil.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import br.com.porteirofacil.PorteiroApplication
import br.com.porteirofacil.data.local.ResponsibleEntity
import br.com.porteirofacil.data.local.StudentEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
class PorteiroViewModel(app: Application) : AndroidViewModel(app) {
    private val application = app as PorteiroApplication
    private val repo = application.repository
    val config = application.secureConfig

    val query = MutableStateFlow("")
    val selectedSeries = MutableStateFlow("")
    val selectedClass = MutableStateFlow("")
    val syncing = MutableStateFlow(false)
    val message = MutableStateFlow<String?>(null)
    val settingsOpen = MutableStateFlow(!config.hasToken())
    val selectedStudent = MutableStateFlow<StudentEntity?>(null)

    val allStudents = repo.observeStudents().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val filteredStudents: StateFlow<List<StudentEntity>> = combine(
        allStudents, query, selectedSeries, selectedClass
    ) { students, q, series, clazz ->
        val needle = q.trim().lowercase()
        students.filter { s ->
            (needle.isBlank() || s.name.lowercase().contains(needle) || s.registration?.lowercase()?.contains(needle) == true) &&
                (series.isBlank() || s.series == series) &&
                (clazz.isBlank() || s.className == clazz)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val responsibles: StateFlow<List<ResponsibleEntity>> = selectedStudent
        .flatMapLatest { student -> student?.let { repo.observeResponsibles(it.id) } ?: flowOf(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun onStart() {
        if (!config.hasToken()) {
            settingsOpen.value = true
            return
        }
        if (repo.needsDailySync()) sync(manual = false)
    }

    fun sync(manual: Boolean = true) {
        if (syncing.value) return
        if (!config.hasToken()) {
            settingsOpen.value = true
            message.value = "Configure o token da API antes de sincronizar."
            return
        }
        viewModelScope.launch {
            syncing.value = true
            message.value = if (manual) "Atualizando dados..." else "Primeira atualização do dia..."
            runCatching { repo.sync() }
                .onSuccess { result ->
                    message.value = "Atualizado: ${result.students} alunos e ${result.responsibles} responsáveis."
                }
                .onFailure { error ->
                    message.value = "Não foi possível atualizar: ${error.message}. O cache local foi mantido."
                }
            syncing.value = false
        }
    }

    fun saveSettings(token: String, baseUrl: String, studentsEndpoint: String, responsiblesEndpoint: String) {
        if (token.isNotBlank()) config.saveToken(token)
        config.baseUrl = baseUrl
        config.studentsEndpoint = studentsEndpoint
        config.responsiblesEndpoint = responsiblesEndpoint
        settingsOpen.value = false
        message.value = "Configuração salva."
        sync()
    }

    fun testSettings(token: String, baseUrl: String, studentsEndpoint: String, responsiblesEndpoint: String) {
        if (token.isNotBlank()) config.saveToken(token)
        config.baseUrl = baseUrl
        config.studentsEndpoint = studentsEndpoint
        config.responsiblesEndpoint = responsiblesEndpoint
        viewModelScope.launch {
            syncing.value = true
            runCatching { repo.testApi() }
                .onSuccess { code -> message.value = "Teste da API: HTTP $code" }
                .onFailure { message.value = "Falha no teste: ${it.message}" }
            syncing.value = false
        }
    }

    fun clearFilters() {
        query.value = ""
        selectedSeries.value = ""
        selectedClass.value = ""
    }
}
