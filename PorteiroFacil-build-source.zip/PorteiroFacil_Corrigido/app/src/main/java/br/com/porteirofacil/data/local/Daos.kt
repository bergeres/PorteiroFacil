package br.com.porteirofacil.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface StudentDao {
    @Query("SELECT * FROM students ORDER BY name COLLATE NOCASE")
    fun observeAll(): Flow<List<StudentEntity>>

    @Query("SELECT * FROM students WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): StudentEntity?

    @Query("SELECT * FROM students")
    suspend fun getAllOnce(): List<StudentEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<StudentEntity>)

    @Query("DELETE FROM students")
    suspend fun clear()
}

@Dao
interface ResponsibleDao {
    @Query("SELECT * FROM responsibles WHERE studentId = :studentId ORDER BY name COLLATE NOCASE")
    fun observeByStudent(studentId: String): Flow<List<ResponsibleEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<ResponsibleEntity>)

    @Query("DELETE FROM responsibles")
    suspend fun clear()
}
