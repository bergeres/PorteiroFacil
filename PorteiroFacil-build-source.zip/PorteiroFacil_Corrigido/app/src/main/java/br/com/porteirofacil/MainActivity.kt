package br.com.porteirofacil

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import br.com.porteirofacil.data.local.ResponsibleEntity
import br.com.porteirofacil.data.local.StudentEntity
import br.com.porteirofacil.ui.PorteiroViewModel
import coil.compose.AsyncImage
import java.io.File
import java.time.OffsetDateTime
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle

class MainActivity : ComponentActivity() {
    private val vm: PorteiroViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        setContent { PorteiroTheme { PorteiroScreen(vm) } }
    }

    override fun onStart() {
        super.onStart()
        vm.onStart()
    }
}

private val Blue = Color(0xFF0A58CA)
private val LightBlue = Color(0xFFF4F8FF)
private val Ink = Color(0xFF122033)

@Composable
fun PorteiroTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Blue,
            secondary = Color(0xFF2276E3),
            background = LightBlue,
            surface = Color.White,
            onBackground = Ink,
            onSurface = Ink
        ),
        content = content
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PorteiroScreen(vm: PorteiroViewModel) {
    val students by vm.filteredStudents.collectAsState()
    val all by vm.allStudents.collectAsState()
    val query by vm.query.collectAsState()
    val series by vm.selectedSeries.collectAsState()
    val clazz by vm.selectedClass.collectAsState()
    val syncing by vm.syncing.collectAsState()
    val message by vm.message.collectAsState()
    val settingsOpen by vm.settingsOpen.collectAsState()
    val selectedStudent by vm.selectedStudent.collectAsState()
    val responsibles by vm.responsibles.collectAsState()

    val seriesOptions = remember(all) { all.map { it.series }.filter { it.isNotBlank() }.distinct().sorted() }
    val classOptions = remember(all, series) {
        all.filter { series.isBlank() || it.series == series }.map { it.className }.filter { it.isNotBlank() }.distinct().sorted()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Porteiro Fácil", fontWeight = FontWeight.Bold)
                        Text("Consulta rápida de alunos", fontSize = 12.sp, color = Color(0xFF607087))
                    }
                },
                actions = {
                    if (syncing) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                    IconButton(onClick = { vm.sync() }, enabled = !syncing) { Icon(Icons.Default.Sync, "Atualizar") }
                    IconButton(onClick = { vm.settingsOpen.value = true }) { Icon(Icons.Default.Settings, "Configurações") }
                }
            )
        },
        containerColor = LightBlue
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            SyncBanner(vm.config.lastSyncAt, syncing, message)
            OutlinedTextField(
                value = query,
                onValueChange = { vm.query.value = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                leadingIcon = { Icon(Icons.Default.Search, null) },
                trailingIcon = if (query.isNotBlank()) { { IconButton(onClick = { vm.query.value = "" }) { Icon(Icons.Default.Close, null) } } } else null,
                placeholder = { Text("Buscar aluno pelo nome ou matrícula") },
                shape = RoundedCornerShape(16.dp)
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterMenu("Série", series, seriesOptions, Modifier.weight(1f)) {
                    vm.selectedSeries.value = it
                    vm.selectedClass.value = ""
                }
                FilterMenu("Turma", clazz, classOptions, Modifier.weight(1f)) { vm.selectedClass.value = it }
                if (series.isNotBlank() || clazz.isNotBlank() || query.isNotBlank()) {
                    FilledTonalIconButton(onClick = { vm.clearFilters() }) { Icon(Icons.Default.FilterAltOff, "Limpar filtros") }
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("${students.size} aluno(s)", fontWeight = FontWeight.SemiBold)
                Text("Consulta local", color = Color(0xFF2F7D32), fontSize = 13.sp)
            }
            if (students.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Badge, null, Modifier.size(64.dp), tint = Color(0xFF9AA9BB))
                        Spacer(Modifier.height(8.dp))
                        Text(if (all.isEmpty()) "Nenhum aluno sincronizado" else "Nenhum aluno encontrado")
                    }
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(150.dp),
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 24.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(students, key = { it.id }) { student ->
                        StudentCard(student) { vm.selectedStudent.value = student }
                    }
                }
            }
        }
    }

    if (selectedStudent != null) {
        StudentDetailDialog(selectedStudent!!, responsibles) { vm.selectedStudent.value = null }
    }
    if (settingsOpen) {
        SettingsDialog(vm, onDismiss = { if (vm.config.hasToken()) vm.settingsOpen.value = false })
    }
}

@Composable
private fun SyncBanner(lastSync: String?, syncing: Boolean, message: String?) {
    Surface(shape = RoundedCornerShape(14.dp), color = Color.White, tonalElevation = 1.dp) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(if (syncing) Icons.Default.CloudSync else Icons.Default.OfflineBolt, null, tint = Blue)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(if (syncing) "Sincronizando com o Siga..." else "Dados disponíveis offline", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Text(message ?: "Última atualização: ${formatDate(lastSync)}", fontSize = 12.sp, color = Color(0xFF607087), maxLines = 2)
            }
        }
    }
}

@Composable
private fun StudentCard(student: StudentEntity, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(1.dp)
    ) {
        Column {
            Box(Modifier.fillMaxWidth().aspectRatio(1f).background(Color(0xFFE7EEF8)), contentAlignment = Alignment.Center) {
                val file = student.localPhotoPath?.let(::File)?.takeIf { it.exists() }
                if (file != null) {
                    AsyncImage(
                        model = file,
                        contentDescription = "Foto de ${student.name}",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Icon(Icons.Default.Person, null, Modifier.size(72.dp), tint = Color(0xFF9AA9BB))
                }
            }
            Column(Modifier.padding(12.dp)) {
                Text(student.name, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(4.dp))
                Text(listOf(student.series, student.className).filter { it.isNotBlank() }.joinToString(" • ").ifBlank { "Turma não informada" }, fontSize = 12.sp, color = Color(0xFF607087))
            }
        }
    }
}

@Composable
private fun StudentDetailDialog(student: StudentEntity, responsibles: List<ResponsibleEntity>, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Fechar") } },
        title = { Text("Ficha do aluno") },
        text = {
            Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally) {
                val file = student.localPhotoPath?.let(::File)?.takeIf { it.exists() }
                Box(Modifier.size(180.dp).clip(RoundedCornerShape(20.dp)).background(Color(0xFFE7EEF8)), contentAlignment = Alignment.Center) {
                    if (file != null) AsyncImage(model = file, contentDescription = student.name, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    else Icon(Icons.Default.Person, null, Modifier.size(100.dp), tint = Color(0xFF9AA9BB))
                }
                Spacer(Modifier.height(12.dp))
                Text(student.name, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                Text("${student.series} • ${student.className}".trim(' ', '•'), color = Color(0xFF607087))
                student.registration?.let { Text("Matrícula: $it", fontSize = 13.sp) }
                HorizontalDivider(Modifier.padding(vertical = 14.dp))
                Text("Responsáveis", Modifier.fillMaxWidth(), fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                if (responsibles.isEmpty()) Text("Nenhum responsável disponível no cache.", color = Color(0xFF607087), fontSize = 13.sp)
                responsibles.forEach { ResponsibleRow(it) }
            }
        },
        shape = RoundedCornerShape(24.dp)
    )
}

@Composable
private fun ResponsibleRow(r: ResponsibleEntity) {
    Surface(Modifier.fillMaxWidth().padding(vertical = 4.dp), shape = RoundedCornerShape(12.dp), color = Color(0xFFF5F7FA)) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(38.dp).clip(CircleShape).background(Color(0xFFDCE9FF)), contentAlignment = Alignment.Center) { Icon(Icons.Default.SupervisorAccount, null, tint = Blue) }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(r.name, fontWeight = FontWeight.SemiBold)
                r.relationship?.let { Text(it, fontSize = 12.sp, color = Color(0xFF607087)) }
                r.phone?.let { Text(it, fontSize = 12.sp) }
                r.email?.let { Text(it, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                val allowed = r.isAuthorizedPickup
                if (allowed != null) {
                    Text(
                        if (allowed) "Autorizado para retirada" else "Sem autorização de retirada",
                        fontSize = 11.sp,
                        color = if (allowed) Color(0xFF2F7D32) else Color(0xFFA33A2B)
                    )
                }
            }
        }
    }
}

@Composable
private fun FilterMenu(label: String, selected: String, options: List<String>, modifier: Modifier = Modifier, onSelect: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
            Text(selected.ifBlank { label }, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            Icon(Icons.Default.ArrowDropDown, null)
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            DropdownMenuItem(text = { Text("Todos") }, onClick = { onSelect(""); expanded = false })
            options.forEach { option -> DropdownMenuItem(text = { Text(option) }, onClick = { onSelect(option); expanded = false }) }
        }
    }
}

@Composable
private fun SettingsDialog(vm: PorteiroViewModel, onDismiss: () -> Unit) {
    var token by remember { mutableStateOf("") }
    var baseUrl by remember { mutableStateOf(vm.config.baseUrl) }
    var studentsEndpoint by remember { mutableStateOf(vm.config.studentsEndpoint) }
    var responsiblesEndpoint by remember { mutableStateOf(vm.config.responsiblesEndpoint) }
    val syncing by vm.syncing.collectAsState()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Configurar API Siga") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("O token é salvo criptografado no Android Keystore. Deixe o campo vazio para manter o token já salvo.", fontSize = 12.sp, color = Color(0xFF607087))
                OutlinedTextField(token, { token = it }, label = { Text("Token de acesso") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
                OutlinedTextField(baseUrl, { baseUrl = it }, label = { Text("URL base") }, singleLine = true)
                OutlinedTextField(studentsEndpoint, { studentsEndpoint = it }, label = { Text("Endpoint de alunos") }, singleLine = true)
                OutlinedTextField(responsiblesEndpoint, { responsiblesEndpoint = it }, label = { Text("Endpoint de responsáveis") }, singleLine = true, supportingText = { Text("Pode ficar vazio se os responsáveis já vierem junto com os alunos.") })
            }
        },
        confirmButton = {
            Button(onClick = { vm.saveSettings(token, baseUrl, studentsEndpoint, responsiblesEndpoint) }, enabled = !syncing && (token.isNotBlank() || vm.config.hasToken())) { Text("Salvar e sincronizar") }
        },
        dismissButton = {
            Row {
                TextButton(onClick = { vm.testSettings(token, baseUrl, studentsEndpoint, responsiblesEndpoint) }, enabled = !syncing && (token.isNotBlank() || vm.config.hasToken())) { Text("Testar") }
                if (vm.config.hasToken()) TextButton(onClick = onDismiss) { Text("Cancelar") }
            }
        },
        shape = RoundedCornerShape(24.dp)
    )
}

private fun formatDate(value: String?): String {
    if (value.isNullOrBlank()) return "ainda não realizada"
    return runCatching {
        OffsetDateTime.parse(value).format(DateTimeFormatter.ofLocalizedDateTime(FormatStyle.SHORT))
    }.getOrDefault(value)
}
