package br.com.porteirofacil.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "students",
    indices = [Index("name"), Index("series"), Index("className")]
)
data class StudentEntity(
    @PrimaryKey val id: String,
    val name: String,
    val registration: String? = null,
    val series: String = "",
    val className: String = "",
    val photoSource: String? = null,
    val localPhotoPath: String? = null,
    val updatedAt: String? = null
)

@Entity(
    tableName = "responsibles",
    primaryKeys = ["studentId", "responsibleId"],
    indices = [Index("studentId")]
)
data class ResponsibleEntity(
    val studentId: String,
    val responsibleId: String,
    val name: String,
    val relationship: String? = null,
    val phone: String? = null,
    val email: String? = null,
    val isAuthorizedPickup: Boolean? = null
)
