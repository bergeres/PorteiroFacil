package br.com.porteirofacil.data.api

data class RemoteStudent(
    val id: String,
    val name: String,
    val registration: String?,
    val series: String,
    val className: String,
    val photo: String?,
    val updatedAt: String?,
    val responsibles: List<RemoteResponsible> = emptyList()
)

data class RemoteResponsible(
    val studentId: String,
    val id: String,
    val name: String,
    val relationship: String?,
    val phone: String?,
    val email: String?,
    val authorizedPickup: Boolean?
)
