package br.com.porteirofacil.data.repository

import android.content.Context
import android.util.Base64
import androidx.room.withTransaction
import br.com.porteirofacil.data.api.SigaApiClient
import br.com.porteirofacil.data.local.AppDatabase
import br.com.porteirofacil.data.local.ResponsibleEntity
import br.com.porteirofacil.data.local.StudentEntity
import br.com.porteirofacil.security.SecureConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File
import java.time.LocalDate
import java.time.OffsetDateTime

class StudentRepository(
    private val context: Context,
    private val db: AppDatabase,
    private val config: SecureConfig
) {
    private val api = SigaApiClient(config)

    fun observeStudents(): Flow<List<StudentEntity>> = db.studentDao().observeAll()
    fun observeResponsibles(studentId: String): Flow<List<ResponsibleEntity>> = db.responsibleDao().observeByStudent(studentId)

    fun needsDailySync(): Boolean = config.lastSyncDate != LocalDate.now().toString()

    suspend fun testApi(): Int = api.testConnection()

    suspend fun sync(): SyncResult = withContext(Dispatchers.IO) {
        val oldById = db.studentDao().getAllOnce().associateBy { it.id }
        val remoteStudents = api.fetchStudents()
        if (remoteStudents.isEmpty()) error("A API não retornou alunos. Verifique o endpoint e as permissões do token.")
        val extraResponsibles = api.fetchResponsibles()
        val photoDir = File(context.filesDir, "student_photos").apply { mkdirs() }

        val students = remoteStudents.map { remote ->
            val old = oldById[remote.id]
            val photoPath = cachePhoto(photoDir, remote.id, remote.photo, old)
            StudentEntity(
                id = remote.id,
                name = remote.name,
                registration = remote.registration,
                series = remote.series,
                className = remote.className,
                photoSource = remote.photo,
                localPhotoPath = photoPath,
                updatedAt = remote.updatedAt
            )
        }
        val embedded = remoteStudents.flatMap { it.responsibles }
        val allResponsibles = (embedded + extraResponsibles)
            .distinctBy { it.studentId + "|" + it.id }
            .map {
                ResponsibleEntity(
                    studentId = it.studentId,
                    responsibleId = it.id,
                    name = it.name,
                    relationship = it.relationship,
                    phone = it.phone,
                    email = it.email,
                    isAuthorizedPickup = it.authorizedPickup
                )
            }

        db.withTransaction {
            db.responsibleDao().clear()
            db.studentDao().clear()
            db.studentDao().insertAll(students)
            if (allResponsibles.isNotEmpty()) db.responsibleDao().insertAll(allResponsibles)
        }

        // Limpa fotos de alunos que não existem mais na base.
        val validIds = students.map { it.id.replace(Regex("[^A-Za-z0-9_-]"), "_") }.toSet()
        photoDir.listFiles()?.forEach { file ->
            if (file.nameWithoutExtension !in validIds) file.delete()
        }

        config.lastSyncDate = LocalDate.now().toString()
        config.lastSyncAt = OffsetDateTime.now().toString()
        SyncResult(students.size, allResponsibles.size, config.lastSyncAt.orEmpty())
    }

    private suspend fun cachePhoto(dir: File, id: String, source: String?, old: StudentEntity?): String? {
        if (source.isNullOrBlank()) return old?.localPhotoPath?.takeIf { File(it).exists() }
        if (old?.photoSource == source && old.localPhotoPath?.let { File(it).exists() } == true) return old.localPhotoPath
        val safeId = id.replace(Regex("[^A-Za-z0-9_-]"), "_")
        val file = File(dir, "$safeId.jpg")
        return runCatching {
            val bytes = when {
                source.startsWith("data:image", true) -> Base64.decode(source.substringAfter(','), Base64.DEFAULT)
                source.length > 600 && !source.startsWith("http", true) -> Base64.decode(source, Base64.DEFAULT)
                else -> api.downloadBytes(source)
            }
            file.writeBytes(bytes)
            file.absolutePath
        }.getOrElse { old?.localPhotoPath?.takeIf { path -> File(path).exists() } }
    }
}

data class SyncResult(val students: Int, val responsibles: Int, val syncedAt: String)
