package br.com.porteirofacil.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

class SecureConfig(context: Context) {
    private val prefs = context.getSharedPreferences("porteiro_secure", Context.MODE_PRIVATE)
    private val keyAlias = "porteiro_facil_api_key"

    var baseUrl: String
        get() = prefs.getString("base_url", "https://siga02.activesoft.com.br/") ?: "https://siga02.activesoft.com.br/"
        set(value) = prefs.edit().putString("base_url", value.trim().let { if (it.endsWith('/')) it else "$it/" }).apply()

    var studentsEndpoint: String
        get() = prefs.getString("students_endpoint", "api/v1/listar_alunos/") ?: "api/v1/listar_alunos/"
        set(value) = prefs.edit().putString("students_endpoint", value.trimStart('/')).apply()

    var responsiblesEndpoint: String
        get() = prefs.getString("responsibles_endpoint", "api/v1/listar_responsaveis/") ?: "api/v1/listar_responsaveis/"
        set(value) = prefs.edit().putString("responsibles_endpoint", value.trimStart('/')).apply()

    var lastSyncDate: String?
        get() = prefs.getString("last_sync_date", null)
        set(value) = prefs.edit().putString("last_sync_date", value).apply()

    var lastSyncAt: String?
        get() = prefs.getString("last_sync_at", null)
        set(value) = prefs.edit().putString("last_sync_at", value).apply()

    fun hasToken(): Boolean = prefs.contains("api_token_enc")

    fun saveToken(token: String) {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val encrypted = cipher.doFinal(token.trim().toByteArray(StandardCharsets.UTF_8))
        val payload = Base64.encodeToString(cipher.iv, Base64.NO_WRAP) + ":" +
            Base64.encodeToString(encrypted, Base64.NO_WRAP)
        prefs.edit().putString("api_token_enc", payload).apply()
    }

    fun getToken(): String? {
        val payload = prefs.getString("api_token_enc", null) ?: return null
        return runCatching {
            val parts = payload.split(":", limit = 2)
            val iv = Base64.decode(parts[0], Base64.NO_WRAP)
            val encrypted = Base64.decode(parts[1], Base64.NO_WRAP)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, iv))
            String(cipher.doFinal(encrypted), StandardCharsets.UTF_8)
        }.getOrNull()
    }

    fun clearToken() = prefs.edit().remove("api_token_enc").apply()

    private fun getOrCreateKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(keyAlias, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                keyAlias,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            ).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return generator.generateKey()
    }
}
