package br.com.porteirofacil.data.api

import br.com.porteirofacil.security.SecureConfig
import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

class SigaApiClient(private val config: SecureConfig) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .build()

    suspend fun fetchStudents(): List<RemoteStudent> = withContext(Dispatchers.IO) {
        val candidates = linkedSetOf(
            config.studentsEndpoint,
            "api/v1/listar_alunos/",
            "api/v1/listar_aluno/",
            "api/v1/alunos/",
            "api/v1/lista_alunos/"
        ).filter { it.isNotBlank() }
        var lastError: Throwable? = null
        for (endpoint in candidates) {
            val result = runCatching {
                fetchAllPages(endpoint, listOf("results", "data", "alunos", "items"))
                    .mapNotNull { parseStudent(it) }
                    .distinctBy { it.id }
            }
            val students = result.getOrNull()
            if (!students.isNullOrEmpty()) {
                config.studentsEndpoint = endpoint
                return@withContext students
            }
            result.exceptionOrNull()?.let { lastError = it }
        }
        throw lastError ?: IllegalStateException("Nenhum endpoint de alunos retornou dados")
    }

    suspend fun fetchResponsibles(): List<RemoteResponsible> = withContext(Dispatchers.IO) {
        if (config.responsiblesEndpoint.isBlank()) return@withContext emptyList()
        val candidates = linkedSetOf(
            config.responsiblesEndpoint,
            "api/v1/listar_responsaveis/",
            "api/v1/listar_responsavel/",
            "api/v1/listar_responsaveis_aluno/",
            "api/v1/listar_responsavel_aluno/"
        ).filter { it.isNotBlank() }
        for (endpoint in candidates) {
            val result = runCatching {
                fetchAllPages(endpoint, listOf("results", "data", "responsaveis", "items"))
                    .mapNotNull { parseResponsible(it, null) }
                    .distinctBy { it.studentId + "|" + it.id }
            }.getOrNull()
            if (!result.isNullOrEmpty()) {
                config.responsiblesEndpoint = endpoint
                return@withContext result
            }
        }
        emptyList()
    }

    private fun fetchAllPages(initialPath: String, arrayKeys: List<String>): List<JsonElement> {
        val output = mutableListOf<JsonElement>()
        var next: String? = initialPath
        var pageCount = 0
        val visited = mutableSetOf<String>()
        while (pageCount < 200) {
            val current = next?.takeIf { it.isNotBlank() } ?: break
            if (!visited.add(current)) break
            val json = getJson(current)
            extractArray(json, arrayKeys).forEach { output.add(it) }
            next = extractNext(json, current)
            pageCount++
        }
        return output
    }

    private fun extractNext(root: JsonElement, currentPath: String): String? {
        if (!root.isJsonObject) return null
        val o = root.asJsonObject
        for (key in listOf("next", "proxima", "proximo", "next_page", "nextPage")) {
            val value = o.get(key) ?: continue
            if (!value.isJsonNull && value.isJsonPrimitive) {
                return value.asString.trim().takeIf { it.isNotBlank() && it.lowercase() != "null" }
            }
        }
        val pagination = listOf("pagination", "paginacao", "meta").firstNotNullOfOrNull { key ->
            o.get(key)?.takeIf { it.isJsonObject }?.asJsonObject
        }
        pagination?.let { p ->
            for (key in listOf("next", "proxima", "proximo", "next_page", "nextPage")) {
                val value = p.get(key) ?: continue
                if (!value.isJsonNull && value.isJsonPrimitive) {
                    val raw = value.asString.trim()
                    if (raw.isNotBlank() && raw.lowercase() != "null") {
                        if (raw.all(Char::isDigit)) return pageUrl(currentPath, raw)
                        return raw
                    }
                }
            }
        }
        return null
    }

    private fun pageUrl(currentPath: String, page: String): String {
        val base = currentPath.replace(Regex("([?&])page=\\d+"), "$1").trimEnd('?', '&')
        return base + (if (base.contains('?')) "&" else "?") + "page=" + page
    }

    suspend fun downloadBytes(urlOrPath: String): ByteArray = withContext(Dispatchers.IO) {
        val url = resolveUrl(urlOrPath)
        val request = authorizedRequest(url).build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("Falha ao baixar foto: HTTP ${response.code}")
            response.body?.bytes() ?: error("Foto vazia")
        }
    }

    suspend fun testConnection(): Int = withContext(Dispatchers.IO) {
        val request = authorizedRequest(resolveUrl(config.studentsEndpoint)).build()
        client.newCall(request).execute().use { it.code }
    }

    private fun getJson(path: String): JsonElement {
        val request = authorizedRequest(resolveUrl(path)).build()
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                error("API Siga retornou HTTP ${response.code}: ${body.take(180)}")
            }
            return JsonParser.parseString(body)
        }
    }

    private fun authorizedRequest(url: String): Request.Builder {
        val token = config.getToken()?.takeIf { it.isNotBlank() } ?: error("Token da API não configurado")
        return Request.Builder()
            .url(url)
            .header("Accept", "application/json")
            .header("Authorization", "Token $token")
            .header("User-Agent", "PorteiroFacil-Android/1.0")
    }

    private fun resolveUrl(path: String): String {
        if (path.startsWith("http://") || path.startsWith("https://")) return path
        return config.baseUrl.trimEnd('/') + "/" + path.trimStart('/')
    }

    private fun extractArray(root: JsonElement, keys: List<String>): JsonArray {
        if (root.isJsonArray) return root.asJsonArray
        if (!root.isJsonObject) return JsonArray()
        val obj = root.asJsonObject
        for (key in keys) {
            val el = obj.get(key)
            if (el != null && el.isJsonArray) return el.asJsonArray
        }
        // Algumas APIs encapsulam em um único objeto antes da lista.
        obj.entrySet().forEach { (_, value) ->
            if (value.isJsonArray) return value.asJsonArray
            if (value.isJsonObject) {
                keys.forEach { key ->
                    value.asJsonObject.get(key)?.takeIf { it.isJsonArray }?.let { return it.asJsonArray }
                }
            }
        }
        return JsonArray()
    }

    private fun parseStudent(el: JsonElement): RemoteStudent? {
        if (!el.isJsonObject) return null
        val o = el.asJsonObject
        val id = text(o, "id", "aluno_id", "codigo", "codigo_aluno", "matricula") ?: return null
        val name = text(o, "nome", "name", "aluno_nome", "nome_aluno", "nome_completo") ?: return null
        val series = text(o, "serie", "serie_nome", "nome_serie", "curso_serie") ?: nestedText(o, "serie", "nome") ?: ""
        val className = text(o, "turma", "turma_nome", "nome_turma", "classe") ?: nestedText(o, "turma", "nome") ?: ""
        val embedded = listOf("responsaveis", "responsibles", "responsavel").firstNotNullOfOrNull { key ->
            o.get(key)?.takeIf { it.isJsonArray }?.asJsonArray
        }?.mapNotNull { parseResponsible(it, id) }.orEmpty()
        return RemoteStudent(
            id = id,
            name = name,
            registration = text(o, "matricula", "registration", "numero_matricula"),
            series = series,
            className = className,
            photo = text(o, "foto", "foto_url", "url_foto", "aluno_foto", "photo", "imagem"),
            updatedAt = text(o, "updated_at", "data_alteracao", "alterado_em", "ultima_alteracao"),
            responsibles = embedded
        )
    }

    private fun parseResponsible(el: JsonElement, fallbackStudentId: String?): RemoteResponsible? {
        if (!el.isJsonObject) return null
        val o = el.asJsonObject
        val studentId = text(o, "aluno_id", "student_id", "id_aluno") ?: fallbackStudentId ?: return null
        val id = text(o, "id", "responsavel_id", "codigo", "id_responsavel") ?: text(o, "cpf") ?: return null
        val name = text(o, "nome", "name", "responsavel_nome", "nome_responsavel", "nome_completo") ?: return null
        return RemoteResponsible(
            studentId = studentId,
            id = id,
            name = name,
            relationship = text(o, "parentesco", "grau_parentesco", "relationship", "tipo_responsavel"),
            phone = text(o, "celular", "telefone", "phone", "telefone_celular"),
            email = text(o, "email", "e_mail"),
            authorizedPickup = bool(o, "autorizado_buscar", "autorizado_saida", "authorized_pickup")
        )
    }

    private fun text(o: JsonObject, vararg keys: String): String? = keys.firstNotNullOfOrNull { key ->
        o.get(key)?.takeUnless { it.isJsonNull || it.isJsonObject || it.isJsonArray }?.asString?.trim()?.takeIf { it.isNotBlank() }
    }

    private fun nestedText(o: JsonObject, objectKey: String, childKey: String): String? =
        o.get(objectKey)?.takeIf { it.isJsonObject }?.asJsonObject?.get(childKey)
            ?.takeUnless { it.isJsonNull }?.asString?.trim()?.takeIf { it.isNotBlank() }

    private fun bool(o: JsonObject, vararg keys: String): Boolean? = keys.firstNotNullOfOrNull { key ->
        o.get(key)?.takeUnless { it.isJsonNull }?.let { e ->
            runCatching { e.asBoolean }.getOrNull() ?: runCatching {
                when (e.asString.trim().lowercase()) {
                    "sim", "s", "1", "true" -> true
                    "nao", "não", "n", "0", "false" -> false
                    else -> null
                }
            }.getOrNull()
        }
    }
}
